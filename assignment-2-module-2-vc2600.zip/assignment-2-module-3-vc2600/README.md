# Assignment 2: When a Wreck Reaches the World Wide Web
# Module 3: Secret Management and Database Encryption

## Introduction

Building on your work from Modules 1 and 2, you'll now focus on protecting sensitive data through proper secret management and database encryption. This module addresses two critical security concerns:

1. Securing **application secrets** (like the Django `SECRET_KEY`)
2. Protecting sensitive gift card data **at rest** through database encryption

## Step 0: Setting Up Your Module 3 Environment

Before beginning this module:
- Ensure you have completed Module 2 successfully
- Pull in your previous work (properly) to continue building on it
- Verify your environment is still properly configured by running your Module 1 and 2 tests

## Step 1: Secret Management

You may have noticed (hopefully) during your work on the previous modules that the Django `SECRET_KEY` was hardcoded in settings.py, creating a serious security risk. Your task is to implement proper secret management practices.

### Requirements:

1. GitHub Secrets Configuration:
   - [Move the Django SECRET_KEY to GitHub repository Secrets](https://docs.github.com/en/actions/security-for-github-actions/security-guides/using-secrets-in-github-actions)
   - Set the secret variable name as `SECRET_KEY` (do not deviate from this)
   - Update your GitHub Actions workflow to use this secret (you need to figure out how to load it so the next step works)
   - Modify settings.py to retrieve `SECRET_KEY` from the environment

2. Local Development Configuration:
   - Create a `.env` file for local development
   - Store your `SECRET_KEY` in this file
   - Update .gitignore to exclude the new `.env` files (like you have done before)
   - As always, verify no `.env` files are committed anywhere in your repository
   - Explain in your write-up why doing it this way allows for seamless testing between your local deployment and your remote deployment on GitHub. 

### Important Considerations:
- Your application must run both locally and in GitHub Actions
- The secret key must be accessed via environment variable 'SECRET_KEY'
- No sensitive data should be committed to the repository
- Your changes should not break existing functionality

## Step 2: Database Encryption

The gift card data in the database needs protection at rest. Currently, all data is stored in plaintext, making it vulnerable if the database is compromised.

### Requirements:

1. Field Encryption:
   - Implement encryption for the Card.data field, you are welcome to encrypt other fields but it's not required
   - You may use Django plugins or external libraries (djfernet is recommended)
   - Handle database migration for encrypted fields properly
   - Update application logic to work with encrypted fields

2. Key Management:
   - Implement proper encryption key management
   - Ensure all card functionality still works after encryption
   - Test that card viewing and usage still function correctly

### Areas Requiring Special Attention:
- The `use_card_view` functionality may need modifications to work with encrypted data
- Not all database fields can be encrypted (e.g., primary/foreign keys) - definitely reflect on this in your write-up (think data structures)
- Test thoroughly after implementing encryption

## Step 3: Documentation

Create a file named `module3.txt` in your repository root that includes:

1. Implementation details:
   - How you implemented database encryption
   - Your key management approach and rationale
   - Any challenges encountered and their resolutions

2. Security considerations:
   - Why certain approaches were chosen
   - Potential limitations of your implementation
   - Any security trade-offs made

## What to Submit

Ensure your repository contains:
- Updated application code with secret management
- Database encryption implementation
- module3.txt
- Updated `.gitignore`
- No committed `.env` files
- Updated GitHub Actions workflow

On Gradescope, submit:
- git_link.txt
- module3.txt

## Testing Your Implementation

Before submission, verify:
- Local development works with `.env` file
- GitHub Actions passes using repository secrets
- Card operations work with encrypted data
- No sensitive data is exposed in your repository
- All existing functionality remains intact

## Ready for Grading

Once you're confident in your implementation:

```bash
git tag -a -m "Completed assign2 module3." assign2mod3handin
git push origin module3
git push origin assign2mod3handin
```

Remember: Only push this tag when you're ready for final grading!

## Tips for Success

1. Test incrementally:
   - Implement secret management first
   - Test thoroughly before moving to database encryption 
   - Verify each change before proceeding
   - Not doing this is a seriously bad idea, sequence matters. The most common issue students face is playing renegade and pushing everything at once, which means it's nearly impossible to properly troubleshoot and debug. Get in the habit of safe and secure development, Continuous Integration ---> Continuous Deployment. Live by this. 

2. Security best practices:
   - Never commit sensitive data
   - Use strong encryption methods
   - Implement proper key management
   - Test all security measures thoroughly

3. Documentation:
   - Document your decisions and their rationale
   - Explain any security trade-offs
   - Detail your testing process

Remember: Security isn't just about implementing features—it's about implementing them correctly and understanding why each measure is important.
