# Assignment 2: When a Wreck Reaches the World Wide Web
# Module 1: Getting Setup

## Introduction

Unfortunately, it seems your company never learns.
Yet again, the company has decided to cut costs and hire Shoddycorp's
Cut-Rate Contracting to write another program.
Despite your pleas, your company insists, Shoddycorp's *real* strength is websites,
and this time they were hired to create a 'high-quality' website.
As usual, they did not live up to that promise, and are not answering calls or emails yet again.
Just like last time, the task of cleaning up their mess falls to you. With no additional information to work on.

Shoddycorp's Cut-Rate Contracting was hired to create a
website that facilitated the sale, gifting, and use of gift cards.
They seemed to have delivered on *most* of the bare functionality of
the project, but the code is not in good shape.

Luckily, Kevin Gallagher (KG) has read through the code already and left
some comments around some of the lines that concern him most.
Comments not prefaced by KG were likely left by the original author, hard to tell!

Like with all of Shoddycorp's Cut-Rate Contracting deliverables, this is not code you would like to
mimic in any way.

## A Reminder from Before: why are we doing things this way?

Let's get one thing straight: this assignment is intentionally messy. Much like the chaotic landscapes of real-world software development, you're not getting a pristine, perfectly documented roadmap. Instead, you're getting a slice of professional reality—where specifications are murky, documentation is sparse, and sometimes you've got to be part detective, part engineer.

Shoddycorp's Cut-Rate Contracting isn't just a fictional name—it's a metaphor. It represents those moments  when you'll receive code, requirements, or systems that are less than ideal. Sometimes dramatically less. The perfectly organized, crystal-clear project? That's a fairy tale. The actual work of application security involves navigating ambiguity, making informed decisions, and reverse-engineering logic from incomplete information.

Your job isn't to focus on the lack of clarity. Your job is to understand, adapt, and solve. You'll need to:

* Read between the lines of comments
* Test methodically to understand underlying assumptions
* Make intelligent guesses about intent
* Document your reasoning
* Build something that works, even when the original specifications feel like they were written in a foreign language

This isn't just a coding assignment. This is learning to be resourceful, to ask the right questions of yourself, and to transform unclear requirements into working solutions. Embrace the uncertainty—it's where real learning happens.

**Again, sometimes the instructions are missing information, or require you to think through the steps and which ones may make more sense. This is part of the assignment, and is part of the challenge. Turn the frustration into a learning experience.**

## Step 1: Setting up Your Environment

In order to complete this assignment, you are required to use the git VCS (Version Control System). For a cheat-sheet of git commands, please see [this](https://github.com/nyutandononline/CLI-Cheat-Sheet/blob/master/git-commands.md). We will be spot checking your commit messages and/or git log (for all asssignments and modules), it is recommended that you write descriptive commit messages so that the evolution of your repository is easy to understand. For a guide to writing good commit messages, please read [this](https://chris.beams.io/posts/git-commit/) and the [Linux kernel's advice on writing good commit messages](https://git.kernel.org/pub/scm/git/git.git/tree/Documentation/SubmittingPatches?id=b23dac905bde28da47543484320db16312c87551#n134). Commits must be signed.

We will also be making use of GitHub Actions,
python 3 and the Django web framework (which you can install with `pip install django`). Some additional tools that may be useful for this assignment (but are not necessary) are sqlite, burp suite, the python requests library, and the web
development console of your favorite browser. If you are running a \*NIX system,
these tools should be preinstalled and/or available in your distribution's
package manager. As always, working within your already setup Docker containers can definitely make life easier! You are truly asking for complexity doing it any other way. **Don't forget to spin up a Docker Container that has your GitHub keys and other settings configured and working within the container!**

## Step 1.1: Configuring .gitignore

To ensure a clean and secure repository, you need to create a .gitignore file that excludes unnecessary or sensitive files. Consider:

* What files does Python automatically generate that shouldn’t be tracked?
* How can sensitive data be accidentally committed, and how can you prevent this?
* What files does Django generate that don’t need to be in version control?
* We do not want our company database to be uploaded!

Think about these points and determine the correct patterns to include in your .gitignore file.
Use your understanding of Python and Django development environments to make informed choices. This will require reading up a bit on both, and trying things out locally. **Keep coming back to this section as you work through the assignment**

## Step 1.2: Setting up Django

Be sure to generate the database that Django relies on. This can be done by running the commands:

```
python3 manage.py makemigrations LegacySite
python3 manage.py migrate
python3 manage.py shell -c 'import import_dbs'
```

We will guide you a bit, but it's important you take the time to read-up on Django yourself, and develop the ability to self-acquire learning the tools. We never know what new software will exist tomorrow! What is important are the fundamental concepts you can keep re-applying whatever the direction the field takes. This absolutely is what sets you apart, getting a cert can be acquired anytime, understanding the why - that's going to pay off in many more ways.

### Command Breakdown

```
python3 manage.py makemigrations LegacySite
```
This command:

* Looks at your models in the LegacySite app (defined in models.py)
* Detects any changes to your models (like new fields, changed field types, etc.)
* Creates new migration files in LegacySite/migrations/
* These migration files are basically Python instructions for how to update your database schema
* Think of it as "preparing" the database changes


Read through the `models.py` and `views.py` files (and the helper
functions in `extras.py`) in the LegacySite folder to get a feel
for what the website is doing and how. You can also try running
the test server and interacting with the site by running the
following command and browsing to 127.0.0.1:8000. (Never hurts to double check your personal configurations isn't overriding this)

```
python3 manage.py migrate
```

This command:

* Takes all the migration files that were created
* Actually executes them against your database
* Creates/modifies tables in your database to match your models
* Keeps track of which migrations have been applied
* Think of it as "applying" the database changes

```
python3 manage.py shell -c 'import import_dbs'
```
This command:

* Opens a Python shell in the context of your Django project
* Immediately runs the import import_dbs command
* import_dbs is a custom script that:
    * Contains initial data for your database
    * Populates your database
    * Sets up any necessary initial records
    * Hint: Probably a good thing to read though!

Think of it as "seeding" your database with initial data

From a security perspective, these commands are important because:

1. They control your database schema - which needs to be properly structured to prevent security issues
2. The migrations themselves become part of your codebase - and need to be reviewed for security
3. Initial data import could contain sensitive information - which needs to be properly handled

## Step 1.3: Running the Server

```
python3 manage.py runserver
```
This command starts Django's built-in development server. Specifically, it:

* Launches a lightweight web server on 127.0.0.1:8000 (localhost, port 8000) - HINT: Great thing to validate and check, can you access this with a browser?
* Automatically reloads when you make code changes
* Provides debug information when errors occur
* Serves your Django application locally for testing

The tests.py file is Django's built-in testing framework. It allows you to:

* Write automated tests for your application
* Test security vulnerabilities systematically
* Verify that fixes don't break existing functionality
* Read through 'tests.py' as this is a great test to call in Actions and to generally check your deployment is working!

**HINT: when reviewing code and seeing how the migrations occur, you should start identifying items that need to go into the `.gitignore`**


### Warnings:

* This is a DEVELOPMENT server only - never use it in production
* By default, it enables Django's debug mode which can expose sensitive information
* It's single-threaded and not optimized for performance
* Useful for testing security vulnerabilities locally

## Step 2: Configure Actions

There are required elements you should have in your GitHub Actions to enable good future testing!

GitHub Actions Configuration
Required elements:
* Valid workflow YAML file in .github/workflows/
* Basic CI pipeline that includes:
    * Python environment setup
    * Dependencies installation
    * Database migration
    * Basic test execution that everything is working


## Tips for Success

1. Take time to understand the existing codebase before making changes
2. Document your findings and decisions
3. Test thoroughly after each significant change
4. Think about security implications of each configuration choice
5. Pay attention to database handling and sensitive data
6. Keep your git commit messages clear and descriptive

## Goodie Bag of Hints & Considerations

Some of these hints are good for Module 1, others are good to start thinking about in preparation for the other modules...

### Security Considerations:

* Pay special attention to database handling in Django - the assignment involves gift cards which are essentially financial instruments
* Be careful with sensitive data like gift card numbers and values - these should never be exposed in logs or debug output
* Watch for potential SQL injection vulnerabilities, especially given the legacy nature of the code
* Review all SQL queries in the codebase, particularly in models.py and extras.py

### Version Control & Environment:

Your .gitignore needs careful consideration - storing sensitive data or credentials in git is a major security risk
Watch out for accidentally committing:

* Local database files
* Environment variables or related files
* Secret keys or credentials
* Debug logs
* Cache files and compiled Python files

### Development Practices:


* Test for security issues locally before pushing changes
* Django has a lot of built-in security features that may be useful, read up on them
* Document any security vulnerabilities you discover in the legacy code
* Pay attention to input validation and sanitization
* Look for potential XSS vulnerabilities in any user input that gets displayed

### Code Review:

* The comments from "KG" likely point to security issues - analyze these carefully
* Don't just fix the obvious issues - think about subtle security implications
* **always** Look for hardcoded credentials or configuration values, do not enter new ones (this is horrendously bad practice)
* Check for proper session handling and authentication

### Testing and Debugging:
* The GitHub Actions workflow should include security-focused tests and tests that help you make sure everything is working (you need to figure out what you need for yourself to be effective)
* Never leave DEBUG=True in production settings
* Be careful with error messages - they shouldn't reveal system details
* Check for information leakage in API responses
* Review all exception handling
* Watch for sensitive data exposure in database queries
* Check for proper access controls on database operations
* Validate that database connections are secure

Remember: This is a learning exercise in identifying and fixing security issues in legacy code. Take time to understand the vulnerabilities before implementing fixes, and document your reasoning for each security decision. If you do not understand the work you are doing, how you are analyzing something or how to approach an issue, take a step back, do more research and re-approach. Think if your fixes cause new issues - sometimes they can truly break things. Test well, think it through.

## What to Submit

Please **only submit a file called `git_link.txt`** that contains the name of your repository to **Gradescope**.
For example, if your repo is located at 'h<span>ttps:</span>//github.com/NYUAppSec__/assignment-2-module-1-exampleaccount', you would submit a text file named `git_link.txt` with one single line that contains <ins><b>only</b></ins> the following:

    assignment-2-module-1-exampleaccount

When you enter your path keep in mind that each semester is different, the above is just an example. Pay attention to your specific repo path.

Remember that <b>Gradescope is not instant</b>. Especially if we have to look into past GitHub action runs. We have a timeout set for 10 minutes, almost all well running code will complete within 5 minutes. Wait for it to complete or timeout before trying to re-run.

To successfully complete the assignment, you must:

* Module 1
    * Have your repository commits be signed and verified .
    * Ensure .gitignore is correctly configured.
    * Successfully generate and migrate the database.
    * Verify the test server is functional.
    * Include a valid GitHub Actions YAML workflow that runs basic tests.

### Ready for Grading

Feel free to start submitting on gradescope to see how you would score. Once you want to lock in your grade push the `assign2mod1handin` tag with the following:

    git tag -a -m "Completed assign2 module1." assign2mod1handin
    git push origin main
    git push origin assign2mod1handin

**DO NOT PUSH THIS TAG UNTIL YOU WANT TO BE GRADED**

## Troubleshooting Hints for Django CI Workflows in GitHub Actions

If your Django tests are failing in GitHub Actions but work locally, consider these diagnostic questions and areas to investigate:

### Key Areas to Examine

#### Python Command Variations

* Have you considered what differences might exist between python and python3 commands in different environments?
* How might the GitHub Actions runner interpret these commands differently than your local machine?
* Try experimenting with command variations to see if behavior changes. Understand why this question is being asked, a little bit of Google-fu on  python vs python3 will pay-off!

#### Workflow Step Organization

* How are your database-related steps organized in your workflow?
* What might happen to environment state between separate workflow steps?
* Consider how the execution context might differ when commands are in the same or different steps.
* What could be the benefits of grouping related operations?

#### Action Version Selection

* What versions of GitHub Actions are you using? Why did you choose it? 
* How might different versions of the same action behave differently?
* Have you tried comparing your workflow with a known working example, focusing on action versions?

#### Python Environment Configuration

* How is your Python environment being configured in the workflow?
* What strategies exist for specifying Python versions? Does it matter? What does the Django manual say?
* What might be the implications of using different approaches to environment setup?

### Diagnostic Approaches

#### Database Debugging

* How can you inspect what's actually in the database during CI execution? What do we do in tests.py?
* What commands could you add to see if expected test data exists?
* How might the test database differ between your local environment and CI? Should it?

#### Understanding GitHub Actions Execution Context

* What do you know about how steps are executed in GitHub Actions?
* How might environment variables and state persist (or not persist) between steps?
* What differences exist between local Django execution and GitHub Actions execution?

#### Comparative Analysis

* Have you tried comparing a working workflow with a non-working one, line by line?
* What seemingly minor differences might have major impacts?
* What happens if you incrementally modify your workflow to match a working one? Have you identified the nuances and understand why there is a difference?

### Investigation Strategy

* Start by examining Python environment differences
* Investigate how database operations are sequenced
* Look at the context in which commands are executed
* Compare working vs. non-working configurations
* Add temporary diagnostic outputs to observe actual state, clear them before submission (comment out for example)

Remember that CI environments often have subtle but important differences from local environments. The key to solving these issues is methodical comparison and experimentation! This can require some time and effort. 
