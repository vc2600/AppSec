# Assignment 2: When a Wreck Reaches the World Wide Web
# Module 2: Security Vulnerability Assessment and Remediation

**Always read the entire assignment fully before starting any step, do not skip the hints and tips at the end!**

## Introduction
Now that you have your development environment set up from Module 1, it's time to dive deeper into the security aspects of the gift card website. Your task is to identify, exploit, and then fix several critical security vulnerabilities that exist in the codebase.

Kevin Gallagher's (KG) comments have highlighted some concerning areas, but there's more to discover. Your role is to thoroughly assess the application's security, document your findings, and implement proper fixes that don't break existing functionality.

## Step 0: Setting Up Your Module 2 Environment
Before beginning this module, ensure you have completed Module 1 successfully. You'll need to pull in your previous work to continue building on it. Remember we covered how to do this in Assignment 1. Remember what you need to look out for when pulling in potential file overlaps!

After you pulled your Module 1 data in. Ensure your environment is still properly configured. Remember your Module 1 tests? Run them here.

## Step 1: Vulnerability Discovery and Exploitation (Part 1)
Your first task is to audit the application and create specific test cases that expose security flaws. You'll need to create a series of attacks that demonstrate different types of vulnerabilities. **All attack files should be placed in a folder called `part1` in your repository.** Hint: read the tips section.

### 1.1 Cross-Site Scripting (XSS)
Create an attack that exploits a XSS vulnerability:

1. Create a file named `xss.txt` containing a URL
2. The URL must start with /foo (`/foo` is just an [example placeholder](https://en.wikipedia.org/wiki/Foobar), replace it with the actual URL you found)
3. When visited in a browser, it must execute alert("hello")
4. Study the HTML templates and view code to find reflection points to leverage

### 1.2 Cross-Site Request Forgery (CSRF)
Create an attack that forces unauthorized gift card gifting:

1. Create a file named `xsrf.html`
2. When opened in a browser, it must automatically gift a card to user 'test2'
3. The attack should work against any logged-in user
4. Note: user 'test2' is already created with password 'test2'

### 1.3 SQL Injection
Create an attack that extracts password information:

1. Create a file named `sqli.gftcrd`
2. Must be a valid JSON-formatted gift card file
3. When uploaded to the vulnerable form, it should retrieve the admin user's password hash
4. Target the 'admin' user account that exists in the database

### 1.4 Command Injection
Create an attack that executes arbitrary commands by creating two files:

1. `cmdi.txt` with the following format:
```bash
foo/2
var1=bar
var2=baz
```
* First line: vulnerable URL
* Subsequent lines: POST parameters in variable=value format
* Should execute `touch pwned` on the server when triggered. Read up on what `touch` does in Linux.

2. `cmdi.gftcrd`:
   The gift card file needed for the attack

### 1.5 Documentation
Create a file named `module2.txt` in the root of your repository that includes for each vulnerability:

1. Description and potential impact
2. How you discovered it
3. Steps to reproduce the exploit
3. --YOU WILL BE ADDING MORE HERE IN OTHER STEPS--


Tools like Burp Suite can help identify these vulnerabilities but are not required. Even the `Inspect Element` tool of your browser is really useful!

Focus on examining:

* HTML source code of templates
* View code implementation
* Form handling
* File upload processing
* Command execution points

## Step 2: Implementing Security Fixes
After successfully identifying and exploiting these vulnerabilities, your next task is to implement proper security fixes. For each vulnerability:

1. Implement appropriate security controls
2. Document your fixes in the code as comments, and include in your `module2.txt` writeup.
3. Verify the fix prevents the original exploit
4. Ensure the fix doesn't break legitimate functionality

Hint: Did you just fix your very specific vulnerability or provide a robust enough fix that handles other forms of the same attack vector? For example you may still fail on Gradescope if we are able to pass a different (but similar) XSS-attack and it gets through. Think broadly, but don't break legitimate functionality!

### Required Security Improvements:
What we want to see you think through:

* proper input validation and sanitization
* CSRF protection mechanisms
* Improve safety of queries for database operations
* Implement secure command execution practices
* Update requirements.txt with any additional security libraries needed (you can compelete this assignment without importing any additional libraries. However, if you feel the absolute need to, it's okay. List in requirements. Advanced and at your own risk).

## Step 3: Testing Your Security Fixes
Create comprehensive test cases for each vulnerability fix. Your tests should:

* Verify that the original exploit no longer works (Hint: perhaps try a few different versions of the exploit)
* Ensure legitimate functionality still works
* Cover edge cases and potential bypass methods
* Integrate with your GitHub Actions workflow

## Step 4: Documentation
Go back to your `module2.txt` write up and build on it to create a comprehensive write-up that includes (expanded on form Step 1):
For each vulnerability:

1. Description and potential impact
2. How you discovered it
3. Steps to reproduce the exploit
4. Implementation details of your fix
5. Verification steps to confirm the fix works
6. Any potential remaining concerns (think about when you first started this assignment, do your commits have any dangerous information in them? It's okay if you do, but we expect you to acknowledge it and reflect on it to avoid a deduction)

## What to Submit

Make sure your repository has the following files in their correct locations.

* xss.txt
* xsrf.html
* sqli.gftcrd
* cmdi.txt
* cmdi.gftcrd
* module2.txt
* Updated source code with security fixes
* Updated test cases

On gradescope we want your `module2.txt` and your `git_link.txt`. Just like the previous assignment, your `git_link.txt` should only contain the name of your assigment repo.
```
assignment-2-module-2-exampleaccount
```

### Ready for Grading

#### Important Security Consideration:
Creating a release tag is a significant action in software development.
When you tag a commit, you are effectively creating a snapshot of your code that becomes publicly accessible and immutable.
This has several security implications:

* **Public Disclosure:** Your code, including any security vulnerabilities you've identified, becomes publicly visible. This is why it's crucial that your fixes are properly implemented before tagging.
* **Permanent Record:** Tags create permanent references in Git history. Unlike commits that can be amended, once a tag is pushed and others have pulled it, it's effectively permanent.
* **Security Context:** Your writeup and code will expose security vulnerabilities. While this is part of the learning process, in a real-world scenario, you would need to follow responsible disclosure practices.

Therefore, before pushing your tag:

* Ensure all identified vulnerabilities are properly fixed
* Verify your documentation is complete
* Double-check that no sensitive information (like API keys or passwords) is included
* Make sure your test cases are working
* Verify your GitHub Actions pipeline passes

Once you're ready to have your submission graded, tag your repository with:
```bash
git tag -a -m "Completed assign2 module2." assign2mod2handin
git push origin module2
git push origin assign2mod2handin
```
**Again, only push tag once ready! This will be your autograder submisison and writeup that is graded. If the write-up is empty, then that's the grade you're going to get.**

### Tips for Success

* Start with thorough code review to understand the application's logic
* Test each vulnerability in isolation before implementing fixes
* Document your progress and findings as you go
* Consider how fixes might interact with each other
* Always verify fixes don't break legitimate functionality
* Keep your GitHub Actions workflow updated with new tests
* Run tests using Django's built-in framework. Add and modify tests in LegacySite/tests.py and execute them with python manage.py test. Use Django's test client for all tests. This approach works seamlessly with GitHub Actions, simplifying your workflow
* You should be able to write all of your tests using the built-in Django test client--there's no need to use something like Selenium. This will also simplify your GitHub Actions testing, which can also just run `python manage.py test`
* You also do not need to carry out the actual attack in the test; you can check that your fix is working as intended. For example, when testing CSRF, it would be challenging to actually open the `xsrf.html` page and carry out the CSRF attack from inside the test case. Instead, you can mimic what the attack does by making a request to the right URL without a CSRF token and checking that the site returns an error. Likewise for verifying your fix for XSS you can check that when getting the attack URL the `<script>` tag is properly escaped.

Note that **by default, Django runs your tests with an empty database — which
means many pages will not work as you expect!** The solution for this is to use
the "fixtures" feature, which lets you load sample data into the test database
before it runs the test:

```
$ mkdir LegacySite/fixtures
$ python manage.py dumpdata -o LegacySite/fixtures/testdata.json
```

Then add at the top of your test case in `LegacySite/tests.py`:

```
class MyTestCase(TestCase):
    fixtures = ['testdata.json']
    # rest of test code goes here
```

This will save a copy of the current database contents into
`LegacySite/fixtures/testdata.json`, and load it when you run the test. You can
update the fixture data by re-running the `python manage.py dumpdata` command.
Remember to add the `LegacySite/fixtures/testdata.json` file to git so that
it is available when you run your GitHub Actions workflow! Test data is made up, it's not real PII so this is not dangerous to push!

Remember: Security isn't just about fixing vulnerabilities—it's about understanding why they exist and how to prevent them in the future. Take time to understand each issue thoroughly before implementing fixes.
