from django.test import TestCase

class HelloWorldTest(TestCase):
    def test_hello_world(self):
        print("Hello World")
        self.assertTrue(True)