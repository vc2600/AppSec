# Assignment 1: Beware of Geeks Bearing Gift Cards
# Module 1

## Introduction

You've been handed the unpleasant task of performing an audit of code
written by your company's least-favorite contractor, Shoddycorp's
Cut-Rate Contracting. The program is designed to read in gift card files
in a legacy binary file format, and then display them in either a simple
text output format, or in JSON format. Unfortunately, Shoddycorp isn't
returning your calls, so you'll have to make do with the comments in the
file and your own testing.

## Why are we doing things this way?

Let's get one thing straight: this assignment is intentionally messy. Much like the chaotic landscapes of real-world software development, you're not getting a pristine, perfectly documented roadmap. Instead, you're getting a slice of professional reality—where specifications are murky, documentation is sparse, and sometimes you've got to be part detective, part engineer.
Shoddycorp's Cut-Rate Contracting isn't just a fictional name—it's a metaphor. It represents those moments  when you'll receive code, requirements, or systems that are less than ideal. Sometimes dramatically less. The perfectly organized, crystal-clear project? That's a fairy tale. The actual work of application security involves navigating ambiguity, making informed decisions, and reverse-engineering logic from incomplete information.

Your job isn't to focus on the lack of clarity. Your job is to understand, adapt, and solve. You'll need to:

* Read between the lines of comments
* Test methodically to understand underlying assumptions
* Make intelligent guesses about intent
* Document your reasoning
* Build something that works, even when the original specifications feel like they were written in a foreign language

This isn't just a coding assignment. This is learning to be resourceful, to ask the right questions of yourself, and to transform unclear requirements into working solutions. Embrace the uncertainty—it's where real learning happens. 

We aren't heartless. Two of our very best engineers, Justin Cappos (JAC) and Brendan Dolan-Gavitt (BDG) have read through the code already and started making comments. Then, saw the disaster and bolted. It's a mess. We've tried to annotate a few places that look suspicious, but there's no doubt that there are many bugs lurking in this code. Make no mistake, this is *not* an example of C code that you want to imitate.

## Module 1: Setting up Your Environment

### Using Git, GitHub, and getting setup

Remember the work you did in Assignment 0 getting setup? In order to complete this assignment, you are required to use the git VCS (Version Control System). For a cheat-sheet of git commands, please see [this](https://github.com/nyutandononline/CLI-Cheat-Sheet/blob/master/git-commands.md). We will be spot checking your commit messages and/or git log (for all asssignments and modules), it is recommended that you write descriptive commit messages so that the evolution of your repository is easy to understand. For a guide to writing good commit messages, please read [this](https://chris.beams.io/posts/git-commit/) and the [Linux kernel's advice on writing good commit messages](https://git.kernel.org/pub/scm/git/git.git/tree/Documentation/SubmittingPatches?id=b23dac905bde28da47543484320db16312c87551#n134).

The next step is to set up GitHub Actions to automatically build and test your code whenever you push a commit. You can find a [tutorial on GitHub Actions here](https://docs.github.com/en/actions/learn-github-actions/introduction-to-github-actions). You are welcome to use this C/C++ GitHub Actions CI template [here](https://github.com/actions/starter-workflows/blob/main/ci/c-cpp.yml). Take a moment to read what that template does, ensure that you understand 'checkout' in GitHub Actions as well, more info [here](https://github.com/actions/checkout).

For now, you should set up GitHub Actions to just run the below (make sure it's exact!):

```
echo "Hello world"
```

Whenever a new commit is pushed to the repository, GitHub Actions will run, and in this case just echo "Hello world"!
To do this, you'll create a file named `.github/workflows/hello.yml`with the correct commands in place.
Check that the Action is running correctly in the GitHub interface.

### Docker Environment Testing
For consistent testing across systems, you can use Docker:

```bash
make container-test
```

This will execute the Docker commands defined in the Makefile:
1. `docker build -t giftcard-tester .` - Builds a Docker image tagged as `giftcard-tester`.
2. `docker run giftcard-tester` - Creates a containerized environment with all necessary dependencies and runs the test suite.
3. Run the test suite in the container

The container provides a consistent testing environment across different systems, ensuring that all tests run under the same conditions. This will set you up for Module 2 and 3!

### Ready for Submission
Make sure to tag this part, push the `assign1mod1handin` tag with the following:

    git tag -a -m "Completed assign1 module1." assign1mod1handin
    git push origin main
    git push origin assign1mod1handin

## What to Submit

Please **only submit a file called `git_link.txt`** that contains the name of your repository to **Gradescope**.
For example, if your repo is located at 'h<span>ttps:</span>//github.com/NYUAppSec__/assignment1-module1-exampleaccount', you would submit a text file named `git_link.txt` with one single line that contains <ins><b>only</b></ins> the following:

    assignment1-module1-exampleaccount

Remember that <b>Gradescope is not instant</b>. Especially if we have to look into past GitHub action runs. We have a timeout set for 10 minutes, almost all well running code will complete within 5 minutes. Wait for it to complete or timeout before trying to re-run. 

Your repository should contain:

* Part 1
  * Your `.github/workflows/hello.yml`
  * At least one signed commit

