import struct
import sys

def read_gift_card_file(file_path):
    with open(file_path, 'rb') as f:
        # Read the file length (first 4 bytes)
        datalen = struct.unpack("<I", f.read(4))[0]
        
        # Read the rest of the data
        data = f.read(datalen - 4)
        
        # Parse Merchant ID (32 bytes)
        merchant_id = data[:32].decode('utf-8').strip()
        data = data[32:]
        
        # Parse Customer ID (32 bytes)
        customer_id = data[:32].decode('utf-8').strip()
        data = data[32:]
        
        # Parse the number of records (1 byte)
        num_records = struct.unpack("<B", data[:1])[0]
        data = data[1:]
        
        print(f"Merchant ID: {merchant_id}")
        print(f"Customer ID: {customer_id}")
        print(f"Number of Records: {num_records}")
        
        # Loop through the records
        for _ in range(num_records):
            record_size = struct.unpack("<I", data[:4])[0]
            data = data[4:]
            record_type = struct.unpack("<I", data[:4])[0]
            data = data[4:]
            
            print(f"  Record Size: {record_size}")
            print(f"  Record Type: {record_type}")
            
            if record_type == 3:  # Message Record
                message = data[:32].decode('utf-8').strip()
                print(f"    Message: {message}")
                data = data[32:]
            else:
                print("    Unknown Record Type")
                break

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python read_gift_card.py <giftcard_file>")
        sys.exit(1)
    
    read_gift_card_file(sys.argv[1])
