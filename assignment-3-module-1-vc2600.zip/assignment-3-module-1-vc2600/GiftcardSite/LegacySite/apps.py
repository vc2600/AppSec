from django.apps import AppConfig


class LegacysiteConfig(AppConfig):
    name = 'LegacySite'
